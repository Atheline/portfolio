-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2022 at 06:40 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbproject`
--
CREATE DATABASE IF NOT EXISTS `dbproject` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dbproject`;

-- --------------------------------------------------------

--
-- Table structure for table `tblcourse`
--

DROP TABLE IF EXISTS `tblcourse`;
CREATE TABLE IF NOT EXISTS `tblcourse` (
  `Courseid` int(11) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(255) NOT NULL,
  `Price` float NOT NULL,
  `Description` text NOT NULL,
  `Duration` int(11) NOT NULL,
  `Seats` int(11) NOT NULL,
  PRIMARY KEY (`Courseid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcourse`
--

INSERT INTO `tblcourse` (`Courseid`, `coursename`, `Price`, `Description`, `Duration`, `Seats`) VALUES
(2, 'Creating website\r\nwith HTML5', 399.99, 'HTML5 is a markup language used for structuring and presenting content\r\non the World Wide Web. It is the fifth and current major version of the HTML standard.', 2, 2),
(3, 'Adobe InDesign', 299.99, 'Adobe InDesign is a desktop publishing software application produced by Adobe Systems. It can be used to create works such as posters, flyers, brochures, magazines, newspapers, presentations, books and eBooks.', 3, 3),
(4, 'Swift programming', 699.99, 'Swift is a powerful and intuitive programming language for macOS, iOS, watchOS and tvOS. Writing Swift code is interactive and fun, the', 4, 3),
(15, 'AdobePhotoshop', 499.99, 'Adobe Photoshop  is an extremely powerful  application that&#39;s  used by many  professional  photographers and  designers. You can  use Photoshop for  almost any kind  of image editing, such as touching  up photos, creating  high-quality  graphics, and  much, much more.', 10, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `regno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `course` varchar(128) NOT NULL,
  `email` varchar(256) NOT NULL,
  `contactnum` int(11) NOT NULL,
  `regdate` date NOT NULL,
  PRIMARY KEY (`regno`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`regno`, `name`, `course`, `email`, `contactnum`, `regdate`) VALUES
(1, 'Adeline', 'Adobe InDesign', 'adeline@gmail.com', 12345678, '2022-03-02'),
(13, 'Adeline', 'Adobe InDesign', 'adeline@email.com', 12345678, '2022-03-01');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
